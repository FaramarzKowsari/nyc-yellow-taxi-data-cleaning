
from pathlib import Path
import pandas as pd

def build_sample():
    rows=[
      [1,'2025-01-03 08:00','2025-01-03 08:18',1,3.2,1,1,161,236,18.0,1.0,0.5,4.0,0.0,1.0,24.5,2.5,0.0,0.75],
      [2,'2025-01-05 10:00','2025-01-05 09:55',1,2.0,1,1,100,230,12.0,0.0,0.5,2.0,0.0,1.0,15.5,2.5,0.0,0.75],
      [1,'2025-01-08 11:00','2025-01-08 11:00',1,0.0,1,2,142,142,3.0,0.0,0.5,0.0,0.0,1.0,4.5,2.5,0.0,0.75],
      [1,'2025-01-10 12:00','2025-01-10 12:05',8,20.0,1,1,132,1,70.0,1.0,0.5,10.0,6.94,1.0,91.94,2.5,1.75,0.75],
      [1,'2025-01-12 13:00','2025-01-12 13:20',2,-1.0,1,1,999,50,15.0,0.0,0.5,3.0,0.0,1.0,19.5,2.5,0.0,0.75],
      [1,'2025-01-15 14:00','2025-01-15 14:30',1,5.0,1,1,50,48,-20.0,0.0,-0.5,0.0,0.0,-1.0,-21.5,-2.5,0.0,-0.75],
      [1,'2024-12-31 23:55','2025-01-01 00:15',1,4.0,1,1,138,161,22.0,1.0,0.5,5.0,6.94,1.0,36.44,2.5,1.75,0.75],
      [1,'2025-01-20 09:00','2025-01-20 14:30',1,30.0,1,1,90,265,120.0,0.0,0.5,20.0,10.0,1.0,154.0,2.5,0.0,0.75],
    ]
    cols=['VendorID','tpep_pickup_datetime','tpep_dropoff_datetime','passenger_count','trip_distance','RatecodeID','store_and_fwd_flag','PULocationID','DOLocationID','fare_amount','extra','mta_tax','tip_amount','tolls_amount','improvement_surcharge','total_amount','congestion_surcharge','Airport_fee','cbd_congestion_fee']
    df=pd.DataFrame(rows,columns=cols)
    df=pd.concat([df,df.iloc[[0]]],ignore_index=True)
    Path('data/sample').mkdir(parents=True,exist_ok=True)
    df.to_parquet('data/sample/yellow_taxi_dirty_sample.parquet',index=False)
    df.to_csv('data/sample/yellow_taxi_dirty_sample.csv',index=False)
    return df
if __name__=='__main__': print(build_sample())
